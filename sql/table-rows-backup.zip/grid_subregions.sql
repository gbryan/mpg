# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 8.0.19)
# Database: mpg
# Generation Time: 2020-03-05 06:21:06 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table grid_subregions
# ------------------------------------------------------------

LOCK TABLES `grid_subregions` WRITE;
/*!40000 ALTER TABLE `grid_subregions` DISABLE KEYS */;

INSERT INTO `grid_subregions` (`id`, `name`, `co2_lb_mwh`, `ch4_lb_mwh`, `n2o_lb_mwh`, `co2e_lb_mwh`, `nox_lb_mwh`, `so2_lb_mwh`)
VALUES
	(1,'ASCC Alaska Grid',1072,0.077,0.011,1077,6.519,0.525),
	(2,'ASCC Miscellaneous',503,0.023,0.004,505,6.958,0.63),
	(3,'WECC Southwest',1044,0.079,0.012,1049,0.961,0.276),
	(4,'WECC California',528,0.033,0.004,530,0.567,0.052),
	(5,'ERCOT All',1009,0.076,0.011,1014,0.545,1.035),
	(6,'FRCC All',1012,0.075,0.01,1016,0.532,0.372),
	(7,'HICC Miscellaneous',1152,0.095,0.015,1159,7.445,4.5),
	(8,'HICC Oahu',1663,0.181,0.028,1675,3.368,8.648),
	(9,'MRO East',1668,0.156,0.026,1679,1.046,1.288),
	(10,'MRO West',1239,0.115,0.02,1247,1.043,1.392),
	(11,'NPCC New England',558,0.09,0.012,564,0.389,0.126),
	(12,'WECC Northwest',651,0.061,0.009,655,0.612,0.439),
	(13,'NPCC NYC/Westchester',636,0.022,0.003,637,0.258,0.016),
	(14,'NPCC Long Island',1178,0.126,0.016,1186,0.861,0.157),
	(15,'NPCC Upstate NY',295,0.021,0.003,296,0.294,0.188),
	(16,'RFC East',758,0.05,0.009,762,0.59,0.571),
	(17,'RFC Michigan',1272,0.067,0.018,1279,0.905,1.71),
	(18,'RFC West',1243,0.108,0.019,1251,0.945,1.199),
	(19,'WECC Rockies',1368,0.137,0.02,1377,1.016,0.638),
	(20,'SPP North',1412,0.149,0.022,1422,0.802,0.459),
	(21,'SPP South',1248,0.095,0.015,1255,0.85,1.66),
	(22,'SERC Mississippi Valley',839,0.05,0.007,842,0.8,0.712),
	(23,'SERC Midwest',1613,0.082,0.026,1622,1.135,2.439),
	(24,'SERC South',1089,0.087,0.013,1095,0.51,0.371),
	(25,'SERC Tennessee Valley',1185,0.093,0.017,1193,0.719,1.004),
	(26,'SERC Virginia/Carolina',805,0.067,0.011,810,0.478,0.342);

/*!40000 ALTER TABLE `grid_subregions` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
